<?php
/*
Plugin Name: Plugin de Integración WooCommerce - TuCompra
Plugin URI: http://www.nuevo.tucompra.com.co/desarrolladores.html
Description: Plugin de integración entre WordPress/WooCommerce con la pasarela de pago TuCompra. Desarrollado por Momotive Marketing de Colombia S.A.S. (www.momotive.com) para Tu Compra S.A.S. 
Version: 2.0
Author: TuCompra S.A.S.
Author URI: http://www.tucompra.com.co/
*/
add_action('plugins_loaded', 'woocommerce_tu_compra_gateway', 0);
function woocommerce_tu_compra_gateway() {
    if(!class_exists('WC_Payment_Gateway')) return;
    
    class WC_Tucompra extends WC_Payment_Gateway {
    

        public function __construct(){
            $this->id                    = 'tucompra';
            $this->icon                  = apply_filters('woocommerce_tucompra_icon', plugins_url('/img/logo2.png', __FILE__));
            $this->has_fields            = false;
            $this->method_title          = 'TuCompra';
            $this->method_description    = 'Integración de Woocommerce a la pasarela de pagos de TuCompra';
            
            $this->init_form_fields();
            $this->init_settings();
            
            $this->title = $this->settings['title'];
            $this->description         = $this->settings['description']; 
            $this->id_demo = $this->settings['id_demo'];
            $this->llave_demo = $this->settings['llave_demo'];
            $this->url_pasarela_demo = $this->settings['url_pasarela_demo'];
   //         $this->redirect_page_id = $this->settings['redirect_page_id'];

            $this->id_prod = $this->settings['id_prod'];
            $this->llave_prod = $this->settings['llave_prod'];
            $this->url_pasarela_prod = $this->settings['url_pasarela_prod'];
            
            $this->test = $this->settings['test'];
            
            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=' )) {
                add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
             } else {
                add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
            }
            add_action("wp_enqueue_scripts", array(&$this, "dcms_insertar_js"));
            add_action('woocommerce_receipt_tucompra', array(&$this, 'receipt_page'));
            add_action('woocommerce_api_'.strtolower(get_class($this)), array(&$this, 'handle_callback')); 
        }
        
        
        
function handle_callback() {   
    global $woocommerce;
    
    header( 'HTTP/1.1 200 OK' );
    if ( ! empty( $_REQUEST['codigoFactura'] ) ) { 
       // get_header('shop');
        if ( ! empty( $_REQUEST['correoComprador'] ) ){
            registro("CONFIRMACION");
        }  
        else {
            registro("RETORNO");
        }
        //$s = print_r($_REQUEST,1);
        //registro($s);

        $transaccionAprobada = $_REQUEST['transaccionAprobada'];

        $valorFactura = number_format($_REQUEST['valorFactura'], 1, '.', '');

        $tucompra = new WC_Tucompra;
        $llaveencripcion = $tucompra->get_api_key();
        $order = new WC_Order($_REQUEST['codigoFactura']); 
        $hash = $llaveencripcion . ';' . $_REQUEST['codigoFactura'] . ';' . $valorFactura . ';' . $_REQUEST['codigoAutorizacion'];

        
        if(!empty($_REQUEST['codigoFactura'])&&!empty($_REQUEST['confirmacion'])) {
            if(!$order->is_paid()) {
                if($transaccionAprobada == -1 || $transaccionAprobada == 2){
                    $order->update_status( 'failed', 'El pago fue rechazado por TuCompra' );
                } else if($transaccionAprobada == 0 ){
                    $order->update_status( 'failed', 'El pago fue rechazado por TuCompra - Pendiente' ); 
                } else if($transaccionAprobada == 1){
                        if ( ! empty( $_REQUEST['correoComprador'] ) )
                            update_post_meta( $order->id, 'Correo Comprador', $_REQUEST['correoComprador'] );
                        if ( ! empty( $_REQUEST['firmaTuCompra'] ) )
                            update_post_meta( $order->id, 'Firma Tu Compra', $_REQUEST['firmaTuCompra'] );
                        if ( ! empty( $_REQUEST['codigoAutorizacion'] ) )
                            update_post_meta( $order->id, 'Codigo Autorizacion', $_REQUEST['codigoAutorizacion'] );
                        if ( ! empty( $_REQUEST['numeroTransaccion'] ) )
                            update_post_meta( $order->id, 'Numero Transaccion', $_REQUEST['numeroTransaccion'] );
                        if ( ! empty( $_REQUEST['nombreMetodo'] ) )
                            update_post_meta( $order->id, 'Metodo de Pago', $_REQUEST['nombreMetodo'] );
                            
                        update_post_meta( $order->id, 'Todas las variables', json_encode($_REQUEST) );

                        update_post_meta( $order->id,'hash', md5($hash) );

                                if ($_REQUEST['firmaTuCompra']==md5($hash)) {

                                    $order->add_order_note('Pago Aprobado por TuCompra.');
                                    $order->payment_complete();
                                 //   $woocommerce->cart->empty_cart();
                                //    if ( 'yes' == $this->debug )
                                //        $this->log->add( 'tucompra', __('Pago completado.', 'tu-compra-woocommerce') );

                                } else {
                                    $order->update_status( 'on-hold', sprintf( __( 'El Pago se esta Procesando: %s', 'tu-compra-woocommerce'), $this->msg_pending ) );
                                    $this->msg['message'] = $this->msg_pending;
                                    $this->msg['class'] = 'woocommerce-info';
                                }
                } 
            }

            exit();
        }
        if (!empty($_REQUEST['codigoFactura'])&&!empty($_REQUEST['retorno'])) {
            if($transaccionAprobada == -1){
                $checkout_url = $woocommerce->cart->get_checkout_url();
                wc_add_notice('Pago Rechazado: El pago fué rechazado por su entidad bancaria, por favor intente nuevamente.', 'error' );
                wp_redirect($checkout_url);  
                exit();
            } else if($transaccionAprobada == 0 ){
                $order->add_order_note('Pago pendiente por confirmar');  
                wc_add_notice( 'Pago Pendiente: El pago aún está pendiente por confirmar por su entidad bancaria.', 'error' );  
                $woocommerce->cart->empty_cart();
                wp_redirect(  $this->get_return_url( $order ) ); 
                exit();                 
            } else if($transaccionAprobada == 1){
                $woocommerce->cart->empty_cart();
                wp_redirect(  $this->get_return_url( $order ) ); 
                exit(); 
            } else if($transaccionAprobada == 2){
                $checkout_url = $woocommerce->cart->get_checkout_url();
                wc_add_notice('El Pago fue Abortado', 'error' );
                wp_redirect($checkout_url);  
                exit(); 
            }else {
                $checkout_url = $woocommerce->cart->get_checkout_url();
                wc_add_notice('Hubo un problema con el pago, por favor comuníquese con nosotros', 'error' );
                wp_redirect($checkout_url);  
                exit();                
            }
        
              //      $redirect_url = ($this->redirect_page_id=="" || $this->redirect_page_id==0)?get_site_url() . "/":get_permalink($this->redirect_page_id);

             //       wp_redirect( $redirect_url );
                            
            
        }
    }
}        
        
        function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Habilitar/Deshabilitar', 'tu_compra'),
                    'type' => 'checkbox',
                    'label' => __('Habilita la pasarela de pago TuCompra', 'tu_compra'),
                    'default' => 'no'),
                'title' => array(
                    'title' => __('Título', 'tu_compra'),
                    'type'=> 'text',
                    'description' => __('Título que el usuario verá durante el proceso de checkout', 'tu_compra'), 
                    'default' => __('TuCompra', 'tu_compra')),
                    
                'description' => array(
                    'title'         => __('Descripción', 'tu_compra'),
                    'type'             => 'textarea',
                    'default'         => __('Pague con tarjeta de crédito, débito o transacción bancaria de forma segura a través de los servidores seguros de Tu Compra.','tu_compra'),
                    'description'     => __('Descripción que el usuario ve al pagar', 'tu_compra'),
                    'desc_tip'         => false
                ),    
                    
                'id_prod' => array(
                    'title' => __('ID Usuario Producción', 'tu_compra'),
                    'type' => 'text',
                    'description' => __('ID único de usuario en TuCompra - Modo Producción', 'tu_compra')),
                'llave_prod' => array(
                    'title' => __('Llave Producción', 'tu_compra'),
                    'type' => 'text',
                    'description' => __('Llave para encriptar la comunicación con TuCompra - Modo Producción', 'tu_compra')),
                'url_pasarela_prod' => array(
                    'title' => __('URL Pasarela Producción', 'tu_compra'),
                    'type' => 'text',
                    'description' => __('URL pasarela de pago TuCompra - Modo Producción', 'tu_compra'),
                    'default' => 'https://gateway2.tucompra.com.co/tc/app/inputs/compra.jsp'),
                    
/**                'redirect_page_id' => array(
                    'title'         => __('Pagina de retorno', 'tu-compra-woocommerce'),
                    'type'             => 'select',
                    'options'         => $this->get_pages(__('Seleccionar Pagina', 'tu-compra-woocommerce')),
                    'description'     => __('Recuerde que si cambia esta opcion se generara una nueva URL de retorno y de confirmacion, que debera entregar a Tu Compra para su configuracion.', 'tu-compra-woocommerce'),
                    'desc_tip'         => false
                ),
*/                    
                'test' => array(
                    'title' => __('Transacciones en Modo Demostración', 'tu_compra'),
                    'type' => 'checkbox',
                    'label' => __('Habilita las transacciones en Modo Demostración', 'tu_compra'),
                    'default' => 'no'),
                'id_demo' => array(
                    'title' => __('ID Usuario Demostración', 'tu_compra'),
                    'type' => 'text',
                    'description' => __('ID único de usuario en TuCompra - Modo Demostración', 'tu_compra')),
                'llave_demo' => array(
                    'title' => __('Llave Demostración', 'tu_compra'),
                    'type' => 'text',
                    'description' => __('Llave para encriptar la comunicación con TuCompra - Modo Demostración', 'tu_compra')),
                'url_pasarela_demo' => array(
                    'title' => __('URL Pasarela Demostración', 'tu_compra'),
                    'type' => 'text',
                    'description' => __('URL pasarela de pago TuCompra - Modo Demostración', 'tu_compra'),
                    'default' => 'https://demover3-1.tucompra.net/tc/app/inputs/compra.jsp'),
            );
        }
        

        public function admin_options() {
           /*
            if($this->settings['redirect_page_id']=="" || $this->settings['redirect_page_id']==0){ echo "no url";
                $redirect_url = get_site_url() . "/";
            }else{
                $redirect_url = get_permalink($this->settings['redirect_page_id']);                
            }
           */ 
            //For wooCoomerce 2.0
            $base_url = add_query_arg( 'wc-api', get_class( $this ), get_site_url() . "/" );
            $retorno_url = add_query_arg( 'retorno', true, $base_url );
            $confirm_url = add_query_arg( 'confirmacion', true, $base_url );
            
            echo '<h3>'.__('Pasarela de pago TuCompra', 'tu_compra').'</h3>';
            echo '<img src="'.plugins_url('/img/logo2.png', __FILE__).'" width="250">';
            echo '<table class="form-table">';
            $this -> generate_settings_html();
         //   $url_confirmacion=plugins_url('/confirmacion.php', __FILE__);
            
            echo '<tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="tu_compra_retorno_url">URL de Retorno</label>
                    </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text"><span>URL de Retorno</span></legend>
                        <input class="input-text regular-input " type="text" name="tu_compra_retorno_url" id="woocommerce_tucompra_return_url" style="" value="'.$retorno_url.'" placeholder="" readonly="true">
                        <p class="description">Dirección URL de retorno, entregar a TuCompra cuando lo soliciten.</p>
                    </fieldset>
                </td>
            </tr>';
            echo '<tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="tu_compra_confirmacion_url">URL de Confirmación</label>
                    </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text"><span>URL de Confirmación</span></legend>
                        <input class="input-text regular-input " type="text" name="tu_compra_confirmacion_url" id="woocommerce_tucompra_return_url" style="" value="'.$confirm_url.'" placeholder="" readonly="true">
                        <p class="description">Dirección URL de confirmación, entregar a TuCompra cuando lo soliciten.</p>
                    </fieldset>
                </td>
            </tr>';
            
            echo '</table>';
        }
        
        function dcms_insertar_js(){ 
            wp_register_script( 'jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js');
        }

        function receipt_page($order){
            ?>
            <script type="text/javascript">
                console.log("carga javascript");
                jQuery(document).ready(function($){
                    console.log("carga el jQuery");
                    document.getElementById("tu_compra_form").submit();
                });
            </script>
        <?php

            echo '<p>'.__('Gracias por su pedido. Será redireccionado a la pagina de Tucompra para completar el pago.', 'tu_compra').'</p>';
            echo $this -> generate_tucompra_form($order);
        }
        

        public function get_params_post($order_id){
            
            global $woocommerce, $wp_version;
            $order = new WC_Order( $order_id );
            $currency = get_woocommerce_currency();
            $productinfo = "";
            $usuario = $this->id_prod; 
            if($this->test == 'yes'){
                $usuario = $this->id_demo;
                $productinfo = "* Modo Demostración * ";
            }

            $productinfo .= "Pedido #$order_id | ";
            $products = $order->get_items();
            foreach($products as $product) {
                $productinfo .= $product['qty'] .' '. $product['name'] . ', ';
            }
            $productinfo = rtrim($productinfo, ', ');
                        
            $tucompra_args = array(
                'usuario'           => $usuario,
                'factura'           => $order_id,
                'valor'             => $order->order_total,
                'tipoMoneda'        => $currency,
                'documentoComprador'=> $order->billing_document,
                'nombreComprador'   => $order->billing_first_name,
                'apellidoComprador'   => $order->billing_last_name,
                'correoComprador'   => $order->billing_email,
                'telefonoComprador' => $order->billing_phone,
                'direccionComprador'=> $order->billing_address_1.' '.$order->billing_address_2,
                'ciudadComprador'   => $order->billing_city,
                'paisComprador'     => $order->billing_country,   
                'campoExtra1'       => $order->order_key,
                'campoExtra2'       => 'WooCommerce '.WOOCOMMERCE_VERSION . ', WordPress '. $wp_version,
                'descripcionFactura'=> $productinfo,
            );
            return $tucompra_args;
        }
                

        public function generate_tucompra_form($order_id){
            $parameters_args = $this->get_params_post($order_id);
            
            $argumentos_gateway = array();
            foreach($parameters_args as $key => $value){
                $argumentos_gateway[] = $key . '=' . $value;
            }
            $params_post = implode('&', $argumentos_gateway);

            $argumentos_gateway = array();
            foreach($parameters_args as $key => $value){
              $argumentos_gateway[] = "<input type='hidden' name='$key' value='$value'/>";
            }
            
            $url_pasarela = $this->url_pasarela_prod; 
            if($this->test == 'yes'){
                $url_pasarela = $this->url_pasarela_demo;
            }
            
            return '<form action="'.$url_pasarela.'" method="post" id="tu_compra_form">' . implode('', $argumentos_gateway) 
                . '</form>';
        }
        

        function process_payment($order_id) {
            global $woocommerce;
            $order = new WC_Order($order_id);
           // $woocommerce->cart->empty_cart();
            if (version_compare(WOOCOMMERCE_VERSION, '2.0.19', '<=' )) {
                return array('result' => 'success', 'redirect' => add_query_arg('order',
                    $order->id, add_query_arg('key', $order->order_key, get_permalink(get_option('woocommerce_pay_page_id'))))
                );
            } else {
            
                $parameters_args = $this->get_params_post($order_id);
                
                $argumentos_gateway = array();
                foreach($parameters_args as $key => $value){
                    $argumentos_gateway[] = $key . '=' . $value;
                }
                $params_post = implode('&', $argumentos_gateway);
            
                return array(
                    'result' => 'success',
                    'redirect' =>  $order->get_checkout_payment_url( true )
                );
            }
        }
        

        function get_api_key() {
            
            if($this->test == 'yes'){
                return $this->settings['llave_demo'];
                
            }
            else {
                return  $this->settings['llave_prod'];
            }
        }    
        
    }


    function add_tu_compra($methods) {
        $methods[] = 'WC_Tucompra';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_tu_compra' );
    
    function registro($msg){
        $logfile = 'registro.log';
        file_put_contents($logfile,date("Y-m-d H:i:s")." | ".$msg."\n",FILE_APPEND);
    }

}