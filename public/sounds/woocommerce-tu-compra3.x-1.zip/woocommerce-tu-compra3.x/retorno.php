<?php
http_response_code(200);

require_once '../../../wp-blog-header.php';
require_once './tucompra.php';
get_header('shop');

$metodosPago = array(
    '1' => 'MasterCard',
    '2' => 'Visa',
    '3' => 'Cuenta Ahorro/Corriente',
    '4' => 'Diners Club',
    '5' => 'American Express',
    '6' => 'Credencial',
    '7' => 'Tarjeta Almacenes Si',
	'8' => 'Sin Seleccionar',	
    '10'=> 'Pruebas',
    '11'=> 'Efecty',
    '12'=> 'Pago Referenciado',
    '17'=> 'Código de Barras',
    '20'=> 'Manual',
    '35'=> 'Ath-Baloto-Éxito-bancos-efectivo',
	'42'=> 'MovilRed',
	'43'=> 'Baloto',
	'44'=> 'Cajero ATH',
	'45'=> 'Efecty Referenciado',
	'47'=> 'Almacenes exito',
	'49'=> 'Punto Red',
	'50'=> 'super Giros',
	'63'=> 'Kupi'
);

if(isset($_REQUEST['transaccionAprobada']))
    $transaccionAprobada = $_REQUEST['transaccionAprobada'];
if(isset($_REQUEST['codigoFactura']))
    $codigoFactura = $_REQUEST['codigoFactura'];
if(isset($_REQUEST['valorFactura']))
    $valorFactura = $_REQUEST['valorFactura'];
if(isset($_REQUEST['codigoAutorizacion']))
    $codigoAutorizacion = $_REQUEST['codigoAutorizacion'];
if(isset($_REQUEST['numeroTransaccion']))
    $numeroTransaccion = $_REQUEST['numeroTransaccion'];
if(isset($_REQUEST['firmaTuCompra']))
    $firmaTuCompra = $_REQUEST['firmaTuCompra'];
if(isset($_REQUEST['campoExtra1']))
    $campoExtra1 = $_REQUEST['campoExtra1'];
if(isset($_REQUEST['campoExtra2']))
    $campoExtra2 = $_REQUEST['campoExtra2'];
if(isset($_REQUEST['campoExtra3']))
    $campoExtra3 = $_REQUEST['campoExtra3'];
if(isset($_REQUEST['metodoPago']))
    $metodoPago = $_REQUEST['metodoPago'];
if(isset($_REQUEST['nombreMetodo']))
    $nombreMetodo = $_REQUEST['nombreMetodo'];

$valorFactura = number_format($valorFactura, 1, '.', '');

$tucompra = new WC_Tucompra;
$llaveencripcion = $tucompra->get_api_key();

$firmaLocal = $llaveencripcion . ';' . $codigoFactura . ';' . $valorFactura . ';' . $codigoAutorizacion;
$firmaLocal_md5 = md5($firmaLocal);

$agradecimiento = '';
// $order = new WC_Order($campoExtra1);
if($transaccionAprobada == -1 || $transaccionAprobada == 2){
    $estadoTx = "Rechazada";
} else if($transaccionAprobada == 0 ){
    $estadoTx = "Pendiente";
} else if($transaccionAprobada == 1){
    $estadoTx = "Aprobada";
}
if (strtoupper($firmaTuCompra) == strtoupper($firmaLocal_md5)) {
    $valorFactura = number_format($valorFactura, 0, '', ',');
?>
<div style="padding-right: 15px;padding-left: 30px;">
<?php echo '<img src="'.plugins_url('/img/logo2.png', __FILE__).'" width="250">';  ?>
<h3>Reporte de la transacci&oacute;n en TuCompra</h3>
<table>
   <tr><td>Pedido #</td><td><?php echo $codigoFactura ?></td></tr>
   <tr><td>Estado de la Transacción</td><td><?php echo $estadoTx ?></td></tr>
   <?php if($transaccionAprobada==1) :?><tr><td>Valor Total</td><td>$ <?php echo $valorFactura ?></td></tr><?php endif; ?>
   <?php if(!empty($numeroTransaccion) && $numeroTransaccion!='00') :?><tr><td>Número de Transacción</td><td><?php echo $numeroTransaccion ?></td></tr><?php endif; ?>
   <?php if(!empty($codigoAutorizacion) && $codigoAutorizacion!='00')  :?><tr><td>Código de Autorización</td><td><?php echo $codigoAutorizacion ?></td></tr><?php endif; ?>
   <?php if(!empty($metodoPago)) :?><tr><td>Método de Pago</td><td><?php echo $nombreMetodo ?></td></tr><?php endif; ?>
</table>
<?php if($transaccionAprobada==0 || $transaccionAprobada==1):?><h2>¡Gracias por su compra!</h2><?php endif; ?>
</div>
<?php
} else {
    echo '<h1><center>La petici&oacute;n es incorrecta! Hay un error en la firma digital.</center></h1>';
}
  
get_footer('shop');

?>