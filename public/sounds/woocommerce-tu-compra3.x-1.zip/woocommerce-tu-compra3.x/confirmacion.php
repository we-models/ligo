<?php
require_once '../../../wp-blog-header.php';
require_once './tucompra.php';



print_r($_REQUEST);

if(isset($_REQUEST['transaccionAprobada']))
    $transaccionAprobada = $_REQUEST['transaccionAprobada'];
if(isset($_REQUEST['codigoFactura']))
    $codigoFactura = $_REQUEST['codigoFactura'];
if(isset($_REQUEST['valorFactura']))
    $valorFactura = $_REQUEST['valorFactura'];
if(isset($_REQUEST['codigoAutorizacion']))
    $codigoAutorizacion = $_REQUEST['codigoAutorizacion'];
if(isset($_REQUEST['numeroTransaccion']))
    $numeroTransaccion = $_REQUEST['numeroTransaccion'];
if(isset($_REQUEST['firmaTuCompra']))
    $firmaTuCompra = $_REQUEST['firmaTuCompra'];
if(isset($_REQUEST['campoExtra1']))
    $campoExtra1 = $_REQUEST['campoExtra1'];
if(isset($_REQUEST['campoExtra2']))
    $campoExtra2 = $_REQUEST['campoExtra2'];
if(isset($_REQUEST['campoExtra3']))
    $campoExtra3 = $_REQUEST['campoExtra3'];
if(isset($_REQUEST['metodoPago']))
    $metodoPago = $_REQUEST['metodoPago'];
if(isset($_REQUEST['nombreMetodo']))
    $nombreMetodo = $_REQUEST['nombreMetodo'];
   
$metodosPago = array(
    '1' => 'MasterCard',
    '2' => 'Visa',
    '3' => 'Cuenta Ahorro/Corriente',
    '4' => 'Diners Club',
    '5' => 'American Express',
    '6' => 'Credencial',
    '7' => 'Tarjeta Almacenes Si',
	'8' => 'Sin Seleccionar',	
    '10'=> 'Pruebas',
    '11'=> 'Efecty',
    '12'=> 'Pago Referenciado',
    '17'=> 'Código de Barras',
    '20'=> 'Manual',
    '35'=> 'Ath-Baloto-Éxito-bancos-efectivo',
	'42'=> 'MovilRed',
	'43'=> 'Baloto',
	'44'=> 'Cajero ATH',
	'45'=> 'Efecty Referenciado',
	'47'=> 'Almacenes exito',
	'49'=> 'Punto Red',
	'50'=> 'super Giros',
	'63'=> 'Kupi'
);

$split = explode('.', $valorFactura);
$decimals = $split[1];
if ($decimals % 10 == 0) {
    $valorFactura = number_format($valorFactura, 1, '.', '');
}
$tucompra = new WC_Tucompra;
$llaveencripcion = $tucompra->get_api_key();

$firmaLocal = $llaveencripcion . ';' . $codigoFactura . ';' . $valorFactura . ';' . $codigoAutorizacion;
$firmaLocal_md5 = md5($firmaLocal);

if ($firmaTuCompra == $firmaLocal_md5)
 { 
    $order = new WC_Order($codigoFactura);
 
    if(!$order->is_paid()) {
        echo "la orden aun no esta paga";
        if($transaccionAprobada == -1 || $transaccionAprobada == 2){
            $order->update_status('failed', __('Transaccion rechazada', 'woothemes'));
            $nota = "Transacción rechazada por TuCompra con Método de Pago: ".$nombreMetodo;
            if(!empty($numeroTransaccion)){
                 $nota .= ", Número de Transacción: ".$numeroTransaccion;
            }
            $order->add_order_note($nota);
            
        }else if($transaccionAprobada == 1){
            
            $nota = "Transacción aprobada por TuCompra con Método de Pago: ".$nombreMetodo;
            if(!empty($numeroTransaccion)){
                 $nota .= ", Número de Transacción: ".$numeroTransaccion;
                 $order->payment_complete($numeroTransaccion);   // Si existe numero de transacción se almacena directamente en la orden
            }
            else {
                $order->payment_complete();  // Se procesa el pago
            }
            if(!empty($codigoAutorizacion)) {
                 $nota .= ", Código de Autorización: ".$codigoAutorizacion;  
            } 
            
            $order->add_order_note($nota); 
            $woocommerce->cart->empty_cart(); 
        }else{
            $order->update_status('failed', __('Transaccion fallida', 'woothemes'));
        }
    }
    else {

        echo "la orden ya esta paga";
        $nota = "Transacción aprobada por TuCompra con Método de Pago: ".$nombreMetodo;
        
        $order->add_order_note($nota);
    }
	
    // Se genera un codigo http 200, que significa que la recepcion fue OK
    http_response_code(200);
}
else {
    registro('Intento de romper la seguridad');
}
?>